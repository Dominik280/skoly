<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulář</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin="" />
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>

</head>
<body>
<script>
        $(document).ready(function() {
            $('#skoly').DataTable();
        });
    </script>
    <div class="container">
    <form method="post" action="<?php echo base_url()?>Controller/formular">  
           <?php  
           if($this->uri->segment(2) == "inserted")  
           {  
                echo '<p class="text-success">Data vložena</p>';  
           }  
           if($this->uri->segment(2) == "updated")  
           {  
                echo '<p class="text-success">Data upravena</p>';  
           }  
           ?>  
           <?php  
           if(isset($user_data))  
           {  
                foreach($user_data->result() as $row)  
                {  
           ?>  
           <div class="form-group">  
                <label>Zadejte Název</label>  
                <input type="text" name="nazev" value="<?php echo $row->nazev; ?>" class="form-control" />  
                <span class="text-danger"><?php echo form_error("nazev"); ?></span>  
           </div>  
           <div class="form-group">  
                <label>Zadejte číslo města</label>  
                <input type="text" name="mesto" value="<?php echo $row->mesto; ?>" class="form-control" />  
                <span class="text-danger"><?php echo form_error("mesto"); ?></span>  
           </div>  
           <div class="form-group">  
                <label>Zadejte geo lat</label>  
                <input type="text" name="geo_lat" value="<?php echo $row->geo_lat; ?>" class="form-control" />  
                <span class="text-danger"><?php echo form_error("geo_lat"); ?></span>  
           </div>  
           <div class="form-group">  
                <label>Zadejte geo long</label>  
                <input type="text" name="geo_long" value="<?php echo $row->geo_long; ?>" class="form-control" />  
                <span class="text-danger"><?php echo form_error("geo_long"); ?></span>  
           </div>  
           <div class="form-group">  
                <input type="hidden" name="hidden_id" value="<?php echo $row->id; ?>" />  
                <input type="submit" name="update" value="Upravit" class="btn btn-info" />  
           </div>       
           <?php       
                }  
           }  
           else  
           {  
           ?>  
           <div class="form-group">  
                <label>Zadejte Název</label>  
                <input type="text" name="nazev" class="form-control" />  
                <span class="text-danger"><?php echo form_error("nazev"); ?></span>  
           </div>  
           <div class="form-group">  
                <label>Zadejte číslo města</label>  
                <input type="text" name="mesto" class="form-control" />  
                <span class="text-danger"><?php echo form_error("mesto"); ?></span>  
           </div>  
           <div class="form-group">  
                <label>Zadejte geo lat</label>  
                <input type="text" name="geo_lat" class="form-control" />  
                <span class="text-danger"><?php echo form_error("geo_lat"); ?></span>  
           </div>  
           <div class="form-group">  
                <label>Zadejte geo long</label>  
                <input type="text" name="geo_long" class="form-control" />  
                <span class="text-danger"><?php echo form_error("geo_long"); ?></span>  
           </div>  
           <div class="form-group">  
                <input type="submit" name="insert" value="Vložit" class="btn btn-info" />  
           </div>       
           <?php  
           }  
           ?>  
      </form> 
      
      <div class="table-responsive">  
           <table  id="skoly" class="table display table-bordered">  
                <thead>
                    <tr>  
                         <th>Počet přijatých</th>  
                         <th>Rok</th>  
                         <th>Název školy</th>  
                         <th>Obor</th>  
                         <th>Upravit</th>   
                         <th>Smazat</th>    
                    </tr>  
                </thead>
                <tbody>
               <?php  
           
                foreach($vypis_skoly as $row)  
                {  
               ?>  
               
                <tr>  
                     <td><?php echo $row->pocet; ?></td>  
                     <td><?php echo $row->rok; ?></td>  
                     <td><?php echo $row->nazev_skoly; ?></td>
                     <td><?php echo $row->nazev_oboru; ?></td>
                     <td><a href="<?php echo base_url(); ?>Controller/update_data/<?php echo $row->id; ?>">Upravit</a></td>  
                     <td><a href="#" class="delete_data" id="<?php echo $row->id; ?>">Smazat</a></td>
                       
                </tr>  
           <?php       
                }  
              
           ?>  
           </tbody>
           </table>  
      </div>  
      <script>  
      $(document).ready(function(){  
           $('.delete_data').click(function(){  
                var id = $(this).attr("id");  
                if(confirm("Opravdu chcete vymazat tuto položku?"))  
                {  
                     window.location="<?php echo base_url(); ?>Controller/delete_data/"+id;  
                }  
                else  
                {  
                     return false;  
                }  
           });  
      });  
      </script>  
    </div>
</body>
</html>