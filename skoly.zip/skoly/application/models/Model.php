<?php

class Model extends CI_model

{
    public function __construct() {
        parent::__construct();
    }



    public function vypis_skoly()  
    {  
         $query = $this->db->query("SELECT skola.id, skola.geo_lat, skola.geo_long, pocet_prijatych.pocet, pocet_prijatych.rok, skola.nazev AS nazev_skoly, obor.nazev AS nazev_oboru
         FROM pocet_prijatych
         JOIN skola ON skola.id = pocet_prijatych.skola
         JOIN obor ON obor.id = pocet_prijatych.obor");  
         return $query->result();  
    }  

    function insert_data($data)  
    {  
         $this->db->insert("skola", $data);  
    }  
    function delete_data($id){  
         $this->db->where("id", $id);  
         $this->db->delete("skola");   
    }  
    function fetch_single_data($id)  
    {  
         $this->db->where("id", $id);  
         $query = $this->db->get("skola");  
         return $query;   
    }  
    function update_data($data, $id)  
    {  
         $this->db->where("id", $id);  
         $this->db->update("skola", $data);  
    }  


}