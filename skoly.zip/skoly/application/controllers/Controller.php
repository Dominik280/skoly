<?php
defined('BASEPATH') OR exit ('No direct script acces allowed');


class Controller extends CI_Controller
{
   public function __construct() {
      parent::__construct();
      $this->load->library('ion_auth');
      $this->load->model('Model');
      $this->load->view('pages/header');

      if(!$this->ion_auth->logged_in())$this->load->view('pages/menu'); //když nejsem přihlášen ->menu
      else if($this->ion_auth->logged_in() && $this->ion_auth->is_admin())$this->load->view('pages/menu_admin'); //když jsem přihlášen a jsem admin ->menu_admin
   }

   
  public function index()
  {
    $data["vypis_skoly"] = $this->Model->vypis_skoly();
    $this->load->view("pages/home", $data);
  }
 

public function home()
{
    $data["vypis_skoly"] = $this->Model->vypis_skoly();
    $this->load->view("pages/home", $data);
}
     

public function formular()  
{    
      $this->load->library('form_validation');  
      $this->form_validation->set_rules("nazev", "nazev", 'required');  
      $this->form_validation->set_rules("mesto", "mesto", 'required|numeric');  
      $this->form_validation->set_rules("geo_lat", "geo_lat", 'required');
      $this->form_validation->set_rules("geo_long", "geo_long", 'required');

      if($this->form_validation->run())  
      {  
           $data = array(  
                "nazev"     =>$this->input->post("nazev"),  
                "mesto"  =>$this->input->post("mesto"),
                "geo_lat"     =>$this->input->post("geo_lat"), 
                "geo_long"     =>$this->input->post("geo_long"));

           if($this->input->post("update"))  
           {  
                $this->Model->update_data($data, $this->input->post("hidden_id"));  
                redirect(base_url() . "upraveno");  
           }

           if($this->input->post("insert"))  
           {  
                $this->Model->insert_data($data);  
                redirect(base_url() . "vlozeno"); 
                 
           }  
      }  
      else  
      {    
          $data["vypis_skoly"] = $this->Model->vypis_skoly(); 
           $this->load->view("pages/formular", $data);    
      }  
}  

 public function inserted()  
 {  
     $data["vypis_skoly"] = $this->Model->vypis_skoly(); 
     $this->load->view("pages/formular", $data);    
 }  

 public function delete_data(){  
      $id = $this->uri->segment(3);  
      $this->Model->delete_data($id);  
      redirect(base_url() . "odstraneno");  
 }  

 public function deleted()  
 {  
   $data["vypis_skoly"] = $this->Model->vypis_skoly(); 
   $this->load->view("pages/formular", $data);    
 }

 public function update_data(){  
      $user_id = $this->uri->segment(3);  
      $data["user_data"] = $this->Model->fetch_single_data($user_id);  
      $data["vypis_skoly"] = $this->Model->vypis_skoly(); 
      $this->load->view("pages/formular", $data);  
 }  
 
 public function updated()  
 {  
     $data["vypis_skoly"] = $this->Model->vypis_skoly(); 
     $this->load->view("pages/formular", $data);    
 }  
}

